// 📦 Importação dos tooltips simbólicos externos
import { buildTooltips } from './tooltip.js';

/* ──────────────────────────────────────────────────────────
 * HUD — atualização estável (sem depender de #tooltip-ritual)
 * - sincroniza badges
 * - normaliza build
 * - aplica classes no <body>
 * - atualiza tooltip via data-attributes
 * - partículas etéreas (limpa antes de criar)
 * ────────────────────────────────────────────────────────── */

/**
 * Atualiza o cabeçalho da HUD com nome do dia e estilo baseado na build ativa.
 * @param {string} nomeDia - Ex.: "Dia 2 — Fragmento 1"
 * @param {string|number} build - "virtuoso" | "profano" | "anomalia" | sinônimos | score numérico
 */
export function atualizarHUD(nomeDia, build) {
  const hudDia   = document.getElementById('hud-dia');
  const hudBuild = document.getElementById('hud-build');

  // ✅ Se o HUD ainda não está no DOM, apenas sai silenciosamente
  if (!hudDia || !hudBuild) {
    console.warn('⚠️ HUD não encontrado no DOM.');
    return;
  }

  // 1) Dia (badge esquerda)
  hudDia.textContent = nomeDia ?? 'Dia —';

  // 2) Build (badge direita) — com dot + label (compatível com o CSS novo)
  const kind = normalizeBuild(build);
  const label = { virtuoso:'Virtuoso', profano:'Profano', anomalia:'Anomalia' }[kind];

  hudBuild.className = `badge build ${kind}`;
  hudBuild.innerHTML = `<span class="dot" aria-hidden="true"></span><span class="label">${label}</span>`;
  hudBuild.setAttribute('aria-label', `Build atual: ${label}`);

  // 3) Tooltip vítrea no próprio badge (data-tooltip)
  const tt = buildTooltips?.[kind]?.texto ?? defaultTooltip(kind);
  hudBuild.setAttribute('data-tooltip', tt);

  // 4) Classe global no <body> (para halos/temas)
  document.body.classList.remove('build-virtuoso','build-profano','build-anomalia');
  document.body.classList.add(`build-${kind}`);

  // 5) Micro animação de troca
  hudBuild.classList.add('changed');
  setTimeout(() => hudBuild.classList.remove('changed'), 360);

  // 6) Partículas — limpa antes de gerar
  limparParticulasEticas();
  gerarParticulasEticas(20);
}

/* ──────────────────────────────────────────────────────────
 * Helpers
 * ────────────────────────────────────────────────────────── */

/** Normaliza a entrada da build (aceita sinônimos/acentos/score numérico) */
function normalizeBuild(input) {
  if (input == null) return readBuildFromBody() ?? 'anomalia';

  // Número → thresholds
  const num = Number(input);
  if (!Number.isNaN(num)) {
    if (num >= 0.34) return 'virtuoso';
    if (num <= -0.34) return 'profano';
    return 'anomalia';
  }

  // Texto → lower + sem acento
  let s = String(input).trim().toLowerCase();
  s = s.normalize('NFD').replace(/\p{Diacritic}/gu,'');

  const map = {
    virtuoso:'virtuoso', justo:'virtuoso', bondoso:'virtuoso', benevolente:'virtuoso',
    profano:'profano', perverso:'profano', mal:'profano', mau:'profano', cruel:'profano',
    anomalia:'anomalia', caotico:'anomalia', caos:'anomalia', neutro:'anomalia'
  };
  return map[s] ?? readBuildFromBody() ?? 'anomalia';
}

/** Lê a build atual das classes do body (fallback) */
function readBuildFromBody() {
  if (document.body.classList.contains('build-virtuoso')) return 'virtuoso';
  if (document.body.classList.contains('build-profano'))  return 'profano';
  if (document.body.classList.contains('build-anomalia')) return 'anomalia';
  return null;
}

/** Texto padrão caso não exista no dicionário externo */
function defaultTooltip(kind) {
  switch (kind) {
    case 'virtuoso': return 'Seu espírito se eleva. Você é um farol.';
    case 'anomalia': return 'Ruído no campo. Você é a exceção que perturba a regra.';
    default:         return 'Seu espírito vacila. Reoriente o curso.';
  }
}

/** 💫 Gera partículas etéreas flutuantes com a cor do tema ativo */
function gerarParticulasEticas(qtd = 20) {
  const container = document.createElement('div');
  container.className = 'particles-container';
  for (let i = 0; i < qtd; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.left = `${Math.random() * 100}vw`;
    p.style.top = `${Math.random() * 100}vh`;
    p.style.animationDuration = `${8 + Math.random() * 4}s`;
    p.style.animationDelay = `${Math.random() * 5}s`;
    container.appendChild(p);
  }
  document.body.appendChild(container);
}

/** 🧹 Remove partículas anteriores para evitar acúmulo */
function limparParticulasEticas() {
  document.querySelectorAll('.particles-container').forEach(n => n.remove());
}
